﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ITCourseCertificateV001
{
    public partial class FormKuis : Form
    {
        public int UserID { get; set; }
        public int KursusID { get; set; }
        public string KursusJudul { get; set; }

        private int skor = 0;
        private int indexSoal = 0;
        private DataTable soalTable;

        public FormKuis()
        {
            InitializeComponent();
        }

        private void FormKuis_Load(object sender, EventArgs e)
        {
            LoadSoal();
            TampilkanSoal();
        }

        private void LoadSoal()
        {
            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string query = "SELECT * FROM Kuis WHERE KursusID = @id";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                da.SelectCommand.Parameters.AddWithValue("@id", KursusID);
                soalTable = new DataTable();
                da.Fill(soalTable);
            }
        }

        private void TampilkanSoal()
        {
            if (indexSoal < soalTable.Rows.Count)
            {
                DataRow row = soalTable.Rows[indexSoal];
                lblPertanyaan.Text = row["Pertanyaan"].ToString();
                rdoA.Text = "A. " + row["PilihanA"].ToString();
                rdoB.Text = "B. " + row["PilihanB"].ToString();
                rdoC.Text = "C. " + row["PilihanC"].ToString();
                rdoD.Text = "D. " + row["PilihanD"].ToString();

                rdoA.Checked = false;
                rdoB.Checked = false;
                rdoC.Checked = false;
                rdoD.Checked = false;
            }
            else
            {
                SelesaiKuis();
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (indexSoal >= soalTable.Rows.Count) return;

            string jawabanBenar = soalTable.Rows[indexSoal]["JawabanBenar"].ToString();
            string jawabanUser = "";

            if (rdoA.Checked) jawabanUser = "A";
            else if (rdoB.Checked) jawabanUser = "B";
            else if (rdoC.Checked) jawabanUser = "C";
            else if (rdoD.Checked) jawabanUser = "D";

            bool benar = jawabanUser == jawabanBenar;
            if (benar) skor += 20;

            SimpanJawaban(jawabanUser, benar);

            indexSoal++;
            TampilkanSoal();
        }

        private void SimpanJawaban(string jawaban, bool benar)
        {
            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string query = "INSERT INTO JawabanUser (UserID, KuisID, Jawaban, IsCorrect) VALUES (@user, @kuis, @jawaban, @correct)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", UserID);
                cmd.Parameters.AddWithValue("@kuis", soalTable.Rows[indexSoal]["KuisID"]);
                cmd.Parameters.AddWithValue("@jawaban", jawaban);
                cmd.Parameters.AddWithValue("@correct", benar);
                cmd.ExecuteNonQuery();
            }
        }

        private void SelesaiKuis()
        {
            string pesan = skor >= 80 ? "Selamat! Anda lulus dan mendapatkan sertifikat." : "Maaf, nilai Anda kurang dari 80.";
            MessageBox.Show($"Nilai Anda: {skor}\n{pesan}", "Hasil Kuis", MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (skor >= 80)
            {
                string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "INSERT INTO Certificate0 (UserID, KursusID, Nilai) VALUES (@user, @kursus, @nilai)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@user", UserID);
                    cmd.Parameters.AddWithValue("@kursus", KursusID);
                    cmd.Parameters.AddWithValue("@nilai", skor);
                    cmd.ExecuteNonQuery();
                }
            }

            // Tampilkan form hasil kuis
            FormHasilKuis hasil = new FormHasilKuis();
            hasil.UserID = this.UserID;
            hasil.KursusID = this.KursusID;
            hasil.KursusJudul = this.KursusJudul; // ← penting
            hasil.NilaiAkhir = this.skor;
            hasil.WindowState = FormWindowState.Maximized;
            hasil.Show();

            this.Close();
        }
    }
}
