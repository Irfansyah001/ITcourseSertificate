﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ITCourseCertificateV001
{
    public partial class FormMenu : Form
    {
        public string LoggedInName { get; set; }
        public int LoggedInUserID { get; set; }

        public FormMenu()
        {
            InitializeComponent();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Selamat datang, " + LoggedInName;

            AddKursusButton(1, "Dasar Pemrograman");
            AddKursusButton(2, "Jaringan Komputer");
            AddKursusButton(3, "UI/UX Design");
            AddKursusButton(4, "Database");
        }

        private void AddKursusButton(int id, string title)
        {
            Button btn = new Button();
            btn.Text = title;
            btn.Tag = id;
            btn.Width = 220;
            btn.Height = 60;
            btn.Margin = new Padding(20);
            btn.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btn.BackColor = Color.LightSteelBlue;
            btn.Cursor = Cursors.Hand;
            btn.Click += KursusButton_Click;

            panelKursus.Controls.Add(btn);
        }

        private void KursusButton_Click(object sender, EventArgs e)
        {
            Button clicked = sender as Button;
            int kursusID = (int)clicked.Tag;
            string judulKursus = clicked.Text;

            FormMateri materiForm = new FormMateri();
            materiForm.KursusID = kursusID;
            materiForm.KursusJudul = judulKursus;
            materiForm.UserID = LoggedInUserID;
            materiForm.WindowState = FormWindowState.Maximized;
            this.Hide();
            materiForm.Show();
        }

        private void panelTOP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }
    }
}
