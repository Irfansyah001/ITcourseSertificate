﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace ITCourseCertificateV001
{
    public partial class FormMateri : Form
    {
        public int KursusID { get; set; }
        public string KursusJudul { get; set; }
        public int UserID { get; set; }

        public FormMateri()
        {
            InitializeComponent();
            this.Resize += new EventHandler(FormMateri_Resize);
        }

        private void FormMateri_Load(object sender, EventArgs e)
        {
            lblKursus.Text = KursusJudul;
            lblKursus.Dock = DockStyle.Top;
            lblKursus.TextAlign = ContentAlignment.MiddleCenter;
            lblKursus.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            lblKursus.Padding = new Padding(0, 10, 0, 10);

            dgvMateri.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dgvMateri.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            btnKerjakanKuis.Width = 200;
            btnKerjakanKuis.Height = 40;
            btnKerjakanKuis.Visible = true;

            FormMateri_Resize(this, EventArgs.Empty);
            LoadMateri();
        }

        private void LoadMateri()
        {
            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT MateriID, JudulMateri, LinkVideo, DurasiMenit FROM Materi WHERE KursusID = @id ORDER BY Urutan ASC";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    da.SelectCommand.Parameters.AddWithValue("@id", KursusID);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvMateri.DataSource = dt;

                    dgvMateri.Columns["MateriID"].Visible = false; // Sembunyikan ID
                    dgvMateri.Columns["JudulMateri"].HeaderText = "Judul Materi";
                    dgvMateri.Columns["LinkVideo"].HeaderText = "Link Video";
                    dgvMateri.Columns["DurasiMenit"].HeaderText = "Durasi (menit)";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Gagal memuat materi: " + ex.Message);
                }
            }
        }

        private void btnKerjakanKuis_Click(object sender, EventArgs e)
        {
            FormKuis kuis = new FormKuis();
            kuis.KursusID = this.KursusID;
            kuis.UserID = this.UserID;
            kuis.WindowState = FormWindowState.Maximized;
            this.Hide();
            kuis.Show();
        }

        private void FormMateri_Resize(object sender, EventArgs e)
        {
            dgvMateri.Width = this.ClientSize.Width - 40;
            dgvMateri.Left = 20;

            btnKerjakanKuis.Left = (this.ClientSize.Width - btnKerjakanKuis.Width) / 2;
            btnKerjakanKuis.Top = dgvMateri.Bottom + 20;
        }

        private void btnUpdateMateri_Click(object sender, EventArgs e)
        {
            if (dgvMateri.CurrentRow == null)
            {
                MessageBox.Show("Pilih materi yang ingin diperbarui.");
                return;
            }

            int materiId = Convert.ToInt32(dgvMateri.CurrentRow.Cells["MateriID"].Value);
            string judulLama = dgvMateri.CurrentRow.Cells["JudulMateri"].Value.ToString();
            string linkLama = dgvMateri.CurrentRow.Cells["LinkVideo"].Value.ToString();
            int durasiLama = Convert.ToInt32(dgvMateri.CurrentRow.Cells["DurasiMenit"].Value);

            string judulBaru = Microsoft.VisualBasic.Interaction.InputBox("Ubah Judul:", "Update Materi", judulLama);
            if (string.IsNullOrWhiteSpace(judulBaru)) return;

            string linkBaru = Microsoft.VisualBasic.Interaction.InputBox("Ubah Link Video:", "Update Materi", linkLama);
            if (string.IsNullOrWhiteSpace(linkBaru)) return;

            string durasiInput = Microsoft.VisualBasic.Interaction.InputBox("Ubah Durasi (menit):", "Update Materi", durasiLama.ToString());
            if (!int.TryParse(durasiInput, out int durasiBaru)) return;

            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string query = "UPDATE Materi SET JudulMateri = @judul, LinkVideo = @link, DurasiMenit = @durasi WHERE MateriID = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@judul", judulBaru);
                cmd.Parameters.AddWithValue("@link", linkBaru);
                cmd.Parameters.AddWithValue("@durasi", durasiBaru);
                cmd.Parameters.AddWithValue("@id", materiId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data materi berhasil diperbarui.");
                LoadMateri();
            }
        }

        private void btnDeleteMateri_Click(object sender, EventArgs e)
        {
            if (dgvMateri.CurrentRow == null)
            {
                MessageBox.Show("Pilih materi yang ingin dihapus.");
                return;
            }

            int materiId = Convert.ToInt32(dgvMateri.CurrentRow.Cells["MateriID"].Value);
            string judul = dgvMateri.CurrentRow.Cells["JudulMateri"].Value.ToString();

            DialogResult confirm = MessageBox.Show($"Yakin ingin menghapus materi \"{judul}\"?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string query = "DELETE FROM Materi WHERE MateriID = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", materiId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Materi berhasil dihapus.");
                LoadMateri();
            }
        }

        private void dgvMateri_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}
