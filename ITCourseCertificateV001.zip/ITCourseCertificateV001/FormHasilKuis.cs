﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace ITCourseCertificateV001
{
    public partial class FormHasilKuis : Form
    {
        public int KursusID { get; set; }
        public string KursusJudul { get; set; }
        public int UserID { get; set; }
        public int NilaiAkhir { get; set; }

        private PrintDocument printDocument1 = new PrintDocument();
        private string NamaLengkapUser;

        public FormHasilKuis()
        {
            InitializeComponent();
            printDocument1.PrintPage += new PrintPageEventHandler(PrintDocument1_PrintPage);
        }

        private void FormHasilKuis_Load(object sender, EventArgs e)
        {
            lblJudul.Text = "Hasil Kuis: " + KursusJudul;
            lblNilai.Text = $"Nilai Akhir Anda: {NilaiAkhir}";
            lblStatus.Text = (NilaiAkhir >= 80) ? "Status: LULUS ✅" : "Status: GAGAL ❌";
            btnCetak.Visible = (NilaiAkhir >= 80);

            NamaLengkapUser = GetUserName(UserID); // Ambil nama lengkap user dari DB
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            FormMenu menu = new FormMenu();
            menu.LoggedInUserID = this.UserID;
            menu.LoggedInName = NamaLengkapUser;
            menu.WindowState = FormWindowState.Maximized;
            menu.Show();
            this.Close();
        }

        private void btnCetak_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = printDocument1;
            preview.ShowDialog();
        }

        private void PrintDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Font headerFont = new Font("Segoe UI", 24, FontStyle.Bold);
            Font normalFont = new Font("Segoe UI", 14);
            Brush brush = Brushes.Black;

            int y = 100;
            g.DrawString("Certificate of Completion", headerFont, brush, new PointF(180, y));
            y += 80;

            g.DrawString($"This is to certify that:", normalFont, brush, new PointF(200, y));
            y += 40;
            g.DrawString($"{NamaLengkapUser}", new Font("Segoe UI", 16, FontStyle.Bold), brush, new PointF(200, y));
            y += 50;

            g.DrawString($"Has successfully completed the course:", normalFont, brush, new PointF(200, y));
            y += 40;
            g.DrawString($"{KursusJudul}", new Font("Segoe UI", 16, FontStyle.Bold), brush, new PointF(200, y));
            y += 50;

            g.DrawString($"With a final score of {NilaiAkhir}", normalFont, brush, new PointF(200, y));
            y += 100;

            g.DrawString("Date: " + DateTime.Now.ToString("dd MMMM yyyy"), normalFont, brush, new PointF(200, y));
        }

        private string GetUserName(int userId)
        {
            string result = "";
            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT FullName FROM Users WHERE UserID = @id", conn);
                cmd.Parameters.AddWithValue("@id", userId);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    result = reader["FullName"].ToString();
                }
            }
            return result;
        }
    }
}
