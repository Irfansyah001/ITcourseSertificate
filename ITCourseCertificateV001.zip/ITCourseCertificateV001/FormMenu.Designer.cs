﻿namespace ITCourseCertificateV001
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelKursus = new System.Windows.Forms.FlowLayoutPanel();
            this.panelTOP = new System.Windows.Forms.Panel();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.panelKursus.SuspendLayout();
            this.panelTOP.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelKursus
            // 
            this.panelKursus.AutoScroll = true;
            this.panelKursus.Controls.Add(this.panelTOP);
            this.panelKursus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelKursus.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelKursus.Location = new System.Drawing.Point(0, 0);
            this.panelKursus.Name = "panelKursus";
            this.panelKursus.Padding = new System.Windows.Forms.Padding(20);
            this.panelKursus.Size = new System.Drawing.Size(800, 450);
            this.panelKursus.TabIndex = 1;
            // 
            // panelTOP
            // 
            this.panelTOP.Controls.Add(this.lblWelcome);
            this.panelTOP.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTOP.Location = new System.Drawing.Point(23, 23);
            this.panelTOP.Name = "panelTOP";
            this.panelTOP.Padding = new System.Windows.Forms.Padding(10);
            this.panelTOP.Size = new System.Drawing.Size(0, 50);
            this.panelTOP.TabIndex = 1;
            this.panelTOP.Paint += new System.Windows.Forms.PaintEventHandler(this.panelTOP_Paint);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(25, 18);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(59, 23);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "label1";
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelKursus);
            this.Name = "FormMenu";
            this.Text = "FormMenu";
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.panelKursus.ResumeLayout(false);
            this.panelTOP.ResumeLayout(false);
            this.panelTOP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel panelKursus;
        private System.Windows.Forms.Panel panelTOP;
        private System.Windows.Forms.Label lblWelcome;
    }
}