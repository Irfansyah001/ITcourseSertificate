﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ITCourseCertificateV001
{
    public partial class FormLogin: Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (username == "" || password == "")
            {
                MessageBox.Show("Harap isi username dan password.");
                return;
            }

            string connString = "Data Source=localhost;Initial Catalog=CertificateCourseDB;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string query = "SELECT * FROM Users WHERE Username = @username AND Password = @password";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string fullName = reader["FullName"].ToString();
                    int userId = Convert.ToInt32(reader["UserID"]);

                    MessageBox.Show("Login berhasil. Selamat datang, " + fullName, "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    FormMenu menu = new FormMenu();
                    menu.LoggedInName = fullName;
                    menu.LoggedInUserID = userId;
                    menu.WindowState = FormWindowState.Maximized;
                    this.Hide();
                    menu.Show();
                }
                else
                {
                    MessageBox.Show("Username atau password salah.");
                }
            }
        }


    }
}
