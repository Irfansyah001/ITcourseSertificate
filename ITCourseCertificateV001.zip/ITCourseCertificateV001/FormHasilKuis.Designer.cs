﻿namespace ITCourseCertificateV001
{
    partial class FormHasilKuis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblNilai = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnKembali = new System.Windows.Forms.Button();
            this.btnCetak = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblJudul
            // 
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJudul.Location = new System.Drawing.Point(20, 20);
            this.lblJudul.Name = "lblJudul";
            this.lblJudul.Size = new System.Drawing.Size(776, 49);
            this.lblJudul.TabIndex = 0;
            this.lblJudul.Text = "Hasil Kuis";
            this.lblJudul.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNilai
            // 
            this.lblNilai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblNilai.Location = new System.Drawing.Point(20, 80);
            this.lblNilai.Name = "lblNilai";
            this.lblNilai.Size = new System.Drawing.Size(760, 25);
            this.lblNilai.TabIndex = 1;
            this.lblNilai.Text = "Nilai Akhir Anda: ";
            this.lblNilai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblStatus.Location = new System.Drawing.Point(20, 120);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(760, 25);
            this.lblStatus.TabIndex = 2;
            this.lblStatus.Text = "Status:";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnKembali
            // 
            this.btnKembali.Location = new System.Drawing.Point(320, 180);
            this.btnKembali.Name = "btnKembali";
            this.btnKembali.Size = new System.Drawing.Size(160, 35);
            this.btnKembali.TabIndex = 3;
            this.btnKembali.Text = "Back to Menu";
            this.btnKembali.UseVisualStyleBackColor = true;
            this.btnKembali.Click += new System.EventHandler(this.btnKembali_Click);
            // 
            // btnCetak
            // 
            this.btnCetak.Location = new System.Drawing.Point(320, 230);
            this.btnCetak.Name = "btnCetak";
            this.btnCetak.Size = new System.Drawing.Size(160, 36);
            this.btnCetak.TabIndex = 4;
            this.btnCetak.Text = "Certificate";
            this.btnCetak.UseVisualStyleBackColor = true;
            this.btnCetak.Visible = false;
            this.btnCetak.Click += new System.EventHandler(this.btnCetak_Click);
            // 
            // FormHasilKuis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCetak);
            this.Controls.Add(this.btnKembali);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblNilai);
            this.Controls.Add(this.lblJudul);
            this.Name = "FormHasilKuis";
            this.Text = "FormHasilKuis";
            this.Load += new System.EventHandler(this.FormHasilKuis_Load);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblNilai;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnKembali;
        private System.Windows.Forms.Button btnCetak;
    }
}
